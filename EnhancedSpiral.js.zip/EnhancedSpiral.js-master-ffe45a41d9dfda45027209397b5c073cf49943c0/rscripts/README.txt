This is a simple list of instructions to run the R server.

* Install R and make sure that you also installed rscript (should come together with the r installation)

* Using a shell navigate inside the directory containing the runServer file (e.g. > cd /rscripts)

* make sure that the rscript executable path is the same as the first line of the runServer script (> which rscript), if not, change the first line with the executable path

* type > chmod +x runServer

* type > ./runServer

* Finally, launch the SpiralPlotDisplay tool, pay attention and check that the server allows Cross Origin requests.
